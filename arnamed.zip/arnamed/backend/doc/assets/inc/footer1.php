<footer class="footer footer-alt">
    2024 - <?php echo date('Y'); ?> &copy; Шұғыла<a href=""></a></a>

</footer>